package com.pdfconverter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfConverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfConverterApplication.class, args);
	}

}
