package com.pdfconverter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfConverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
